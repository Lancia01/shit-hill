# Laravel Roblox Clone
Originally written in June-July 2021 to get better with Laravel and to have something fun to work on.

If you need any help, feel free to contact me on [Discord](https://discordhub.com/profile/670619648810811423).

As a reminder, this Repository is no longer maintained. It exists purely for educational purposes, and any other use cases are strongly discouraged. But if you do ignore this note, to get it up and running you will need to fix some things first (since all branding has been removed from the source), and staff actions also aren't logged so I suggest implementing that.

Also nothing is cached so yeah, another reason not to use it in production.
